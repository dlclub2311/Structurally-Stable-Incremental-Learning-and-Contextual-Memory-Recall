from . import (
    my_resnet, resnet
)