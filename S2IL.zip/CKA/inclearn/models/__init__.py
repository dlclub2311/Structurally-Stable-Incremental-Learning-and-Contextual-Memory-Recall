# flake8: noqa
from .base import IncrementalLearner
from .icarl import ICarl
from .s2il import S2IL
